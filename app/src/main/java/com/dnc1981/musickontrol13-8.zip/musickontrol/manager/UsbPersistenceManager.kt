package com.dnc1981.musickontrol.manager

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

class UsbPersistenceManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("usb_persistence", Context.MODE_PRIVATE)

    fun guardarUsbUri(uri: Uri) {
        prefs.edit().putString("last_usb_uri", uri.toString()).apply()

        // ✅ PERSISTIR PERMISO
        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun obtenerUsbUriGuardado(): Uri? {
        val uriString = prefs.getString("last_usb_uri", null) ?: return null
        return try {
            Uri.parse(uriString)
        } catch (e: Exception) {
            null
        }
    }

    fun limpiarUsbUri() {
        prefs.edit().remove("last_usb_uri").apply()
    }

    fun verificarUsbDisponible(uri: Uri): Boolean {
        return try {
            val doc = DocumentFile.fromTreeUri(context, uri)
            doc != null && doc.exists()
        } catch (e: Exception) {
            false
        }
    }
}
