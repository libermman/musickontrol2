package com.dnc1981.musickontrol.service

import android.app.PendingIntent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession

class MusicLibraryService : MediaLibraryService() {

    private var mediaLibrarySession: MediaLibrarySession? = null
    private var exoPlayer: ExoPlayer? = null

    override fun onCreate() {
        super.onCreate()

        val audioAttributes = AudioAttributes.Builder()
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .setUsage(C.USAGE_MEDIA)
            .build()

        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, true)
            .build()
            .apply {
                playWhenReady = true
                repeatMode = Player.REPEAT_MODE_OFF
                shuffleModeEnabled = false
            }

        exoPlayer = player

        val sessionActivityPendingIntent = packageManager
            ?.getLaunchIntentForPackage(packageName)
            ?.let { launchIntent ->
                PendingIntent.getActivity(
                    this,
                    0,
                    launchIntent,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            }

        val callback = object : MediaLibrarySession.Callback {
            // Preparado para futuras funciones AAOS:
            // búsqueda, árbol multimedia, favoritos, comandos personalizados, etc.
        }

        mediaLibrarySession = MediaLibrarySession.Builder(
            this,
            player,
            callback
        ).apply {
            sessionActivityPendingIntent?.let {
                setSessionActivity(it)
            }
        }.build()
    }

    override fun onGetSession(
        controllerInfo: MediaSession.ControllerInfo
    ): MediaLibrarySession? {
        return mediaLibrarySession
    }

    override fun onDestroy() {
        try {
            mediaLibrarySession?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        mediaLibrarySession = null

        try {
            exoPlayer?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        exoPlayer = null

        super.onDestroy()
    }
}
