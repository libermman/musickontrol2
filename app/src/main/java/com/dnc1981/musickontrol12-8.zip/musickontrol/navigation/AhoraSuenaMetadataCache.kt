package com.dnc1981.musickontrol.navigation

import android.graphics.Bitmap
import android.net.Uri

data class CachedTrackMetadata(
    val title: String,
    val artist: String,
    val album: String,
    val artwork: Bitmap?
)

object AhoraSuenaMetadataCache {
    private var cachedUri: String? = null
    private var cachedKey: Int = -999
    private var cachedData: CachedTrackMetadata? = null

    fun get(uri: Uri?, reloadKey: Int): CachedTrackMetadata? {
        if (uri == null) return null
        val uriString = uri.toString()
        return if (uriString == cachedUri && reloadKey == cachedKey) {
            cachedData
        } else {
            null
        }
    }

    fun put(uri: Uri?, reloadKey: Int, data: CachedTrackMetadata) {
        if (uri == null) return
        cachedUri = uri.toString()
        cachedKey = reloadKey
        cachedData = data
    }

    fun clearForced() {
        cachedUri = null
        cachedKey = -999
        cachedData = null
    }

    fun clear() {
        clearForced()
    }
}