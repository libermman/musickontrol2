package com.dnc1981.musickontrol.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import androidx.media3.common.Player

class AudioFocusManager(private val context: Context, private val exoPlayer: Player) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null
    private var wasPlayingBeforeFocusLoss = false
    private var previousVolume = 1f

    private val audioFocusListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            // ✅ RECUPERA EL FOCO (llamada terminada, notificación pasó)
            AudioManager.AUDIOFOCUS_GAIN -> {
                exoPlayer.volume = previousVolume
                if (wasPlayingBeforeFocusLoss) {
                    exoPlayer.play()
                }
            }

            // ✅ PÉRDIDA TEMPORAL (notificación, llamada entrante)
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                wasPlayingBeforeFocusLoss = exoPlayer.isPlaying
                exoPlayer.pause()
            }

            // ✅ PÉRDIDA TEMPORAL CON BAJAR VOLUMEN (música de fondo de otra app)
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                if (exoPlayer.isPlaying) {
                    previousVolume = exoPlayer.volume
                    exoPlayer.volume = 0.3f // Baja a 30% del volumen
                }
            }

            // ✅ PÉRDIDA PERMANENTE (otra app tomó control de audio)
            AudioManager.AUDIOFOCUS_LOSS -> {
                wasPlayingBeforeFocusLoss = false
                exoPlayer.pause()
            }
        }
    }

    fun requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // ✅ Android 8.0+
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()

            audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(audioAttributes)
                .setOnAudioFocusChangeListener(audioFocusListener)
                .build()

            audioManager.requestAudioFocus(audioFocusRequest!!)
        } else {
            // ✅ Android 7.1 y anteriores
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                audioFocusListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            )
        }
    }

    fun abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let {
                audioManager.abandonAudioFocusRequest(it)
            }
        } else {
            @Suppress("DEPRECATION")
            audioManager.abandonAudioFocus(audioFocusListener)
        }
    }

    fun release() {
        abandonAudioFocus()
    }
}