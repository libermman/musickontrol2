package com.dnc1981.musickontrol.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class MusicDatabaseHelper(context: Context) :
    SQLiteOpenHelper(
        context,
        "musiclibrary.db",
        null,
        1
    ) {

    override fun onCreate(db: SQLiteDatabase) {

        db.execSQL(
            """
            CREATE TABLE folders(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                parent TEXT,
                path TEXT UNIQUE,
                name TEXT,
                scanOrder INTEGER
            );
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE songs(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                folderPath TEXT,
                fileName TEXT,
                title TEXT,
                track INTEGER,
                duration INTEGER,
                uri TEXT
            );
            """.trimIndent()
        )

    }

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        if (!db.isReadOnly) {
            db.enableWriteAheadLogging()
        }
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
    }

    /**
     * Obtiene todas las carpetas en orden de escaneo
     */
    fun getFolders(): List<String> {

        val folders = mutableListOf<String>()

        try {
            val cursor = readableDatabase.rawQuery(
                """
                SELECT path
                FROM folders
                ORDER BY scanOrder
                """.trimIndent(),
                null
            )

            while (cursor.moveToNext()) {
                folders.add(cursor.getString(0))
            }

            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return folders

    }

    /**
     * Obtiene todas las canciones de una carpeta
     */
    fun getSongs(folderPath: String): List<String> {

        val songs = mutableListOf<String>()

        try {
            val cursor = readableDatabase.rawQuery(
                """
                SELECT uri
                FROM songs
                WHERE folderPath=?
                ORDER BY fileName COLLATE NOCASE
                """.trimIndent(),
                arrayOf(folderPath)
            )

            while (cursor.moveToNext()) {
                songs.add(cursor.getString(0))
            }

            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return songs

    }

    /**
     * Obtiene TODAS las canciones del USB.
     * Usado para shuffle global.
     */
    fun getAllSongs(): List<String> {

        val songs = mutableListOf<String>()

        try {
            val cursor = readableDatabase.rawQuery(
                """
                SELECT uri
                FROM songs
                ORDER BY folderPath, fileName COLLATE NOCASE
                """.trimIndent(),
                null
            )

            while (cursor.moveToNext()) {
                songs.add(cursor.getString(0))
            }

            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return songs

    }

    /**
     * Obtiene la siguiente carpeta física registrada,
     * tenga canciones o no.
     */
    fun getNextFolder(current: String): String? {

        var result: String? = null

        try {
            val cursor = readableDatabase.rawQuery(
                """
                SELECT path
                FROM folders
                WHERE scanOrder >
                (
                    SELECT scanOrder
                    FROM folders
                    WHERE path=?
                )
                ORDER BY scanOrder
                LIMIT 1
                """.trimIndent(),
                arrayOf(current)
            )

            if (cursor.moveToFirst()) {
                result = cursor.getString(0)
            }

            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return result

    }

    /**
     * Obtiene la carpeta física anterior registrada,
     * tenga canciones o no.
     */
    fun getPreviousFolder(current: String): String? {

        var result: String? = null

        try {
            val cursor = readableDatabase.rawQuery(
                """
                SELECT path
                FROM folders
                WHERE scanOrder <
                (
                    SELECT scanOrder
                    FROM folders
                    WHERE path=?
                )
                ORDER BY scanOrder DESC
                LIMIT 1
                """.trimIndent(),
                arrayOf(current)
            )

            if (cursor.moveToFirst()) {
                result = cursor.getString(0)
            }

            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return result

    }

    /**
     * ✅ FUNCIÓN CLAVE
     *
     * Obtiene la siguiente carpeta REPRODUCIBLE.
     * Una carpeta reproducible es una carpeta que tiene al menos una canción
     * asociada en la tabla songs.
     */
    fun getNextDiskFolder(currentFolderPath: String): String? {

        var result: String? = null

        try {
            val cursor = readableDatabase.rawQuery(
                """
                SELECT f.path
                FROM folders f
                WHERE f.scanOrder >
                (
                    SELECT scanOrder
                    FROM folders
                    WHERE path=?
                )
                AND EXISTS
                (
                    SELECT 1
                    FROM songs s
                    WHERE s.folderPath = f.path
                    LIMIT 1
                )
                ORDER BY f.scanOrder ASC
                LIMIT 1
                """.trimIndent(),
                arrayOf(currentFolderPath)
            )

            if (cursor.moveToFirst()) {
                result = cursor.getString(0)
            }

            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return result

    }

    /**
     * ✅ FUNCIÓN CLAVE
     *
     * Obtiene la carpeta REPRODUCIBLE anterior.
     */
    fun getPreviousDiskFolder(currentFolderPath: String): String? {

        var result: String? = null

        try {
            val cursor = readableDatabase.rawQuery(
                """
                SELECT f.path
                FROM folders f
                WHERE f.scanOrder <
                (
                    SELECT scanOrder
                    FROM folders
                    WHERE path=?
                )
                AND EXISTS
                (
                    SELECT 1
                    FROM songs s
                    WHERE s.folderPath = f.path
                    LIMIT 1
                )
                ORDER BY f.scanOrder DESC
                LIMIT 1
                """.trimIndent(),
                arrayOf(currentFolderPath)
            )

            if (cursor.moveToFirst()) {
                result = cursor.getString(0)
            }

            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return result

    }

    /**
     * Obtiene la ruta de la carpeta a partir de un URI de canción
     */
    fun getFolderPathBySongUri(songUri: String): String? {

        var result: String? = null

        try {
            val cursor = readableDatabase.rawQuery(
                """
                SELECT folderPath
                FROM songs
                WHERE uri=?
                LIMIT 1
                """.trimIndent(),
                arrayOf(songUri)
            )

            if (cursor.moveToFirst()) {
                result = cursor.getString(0)
            }

            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return result

    }

    /**
     * Obtiene la primera carpeta física.
     */
    fun getFirstFolder(): String? {

        var result: String? = null

        try {
            val cursor = readableDatabase.rawQuery(
                """
                SELECT path
                FROM folders
                ORDER BY scanOrder
                LIMIT 1
                """.trimIndent(),
                null
            )

            if (cursor.moveToFirst()) {
                result = cursor.getString(0)
            }

            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return result

    }

    /**
     * Obtiene la última carpeta física.
     */
    fun getLastFolder(): String? {

        var result: String? = null

        try {
            val cursor = readableDatabase.rawQuery(
                """
                SELECT path
                FROM folders
                ORDER BY scanOrder DESC
                LIMIT 1
                """.trimIndent(),
                null
            )

            if (cursor.moveToFirst()) {
                result = cursor.getString(0)
            }

            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return result

    }

    /**
     * Obtiene la primera carpeta reproducible del USB.
     */
    fun getFirstPlayableFolder(): String? {

        var result: String? = null

        try {
            val cursor = readableDatabase.rawQuery(
                """
                SELECT f.path
                FROM folders f
                WHERE EXISTS
                (
                    SELECT 1
                    FROM songs s
                    WHERE s.folderPath = f.path
                    LIMIT 1
                )
                ORDER BY f.scanOrder ASC
                LIMIT 1
                """.trimIndent(),
                null
            )

            if (cursor.moveToFirst()) {
                result = cursor.getString(0)
            }

            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return result

    }

    /**
     * Obtiene la última carpeta reproducible del USB.
     */
    fun getLastPlayableFolder(): String? {

        var result: String? = null

        try {
            val cursor = readableDatabase.rawQuery(
                """
                SELECT f.path
                FROM folders f
                WHERE EXISTS
                (
                    SELECT 1
                    FROM songs s
                    WHERE s.folderPath = f.path
                    LIMIT 1
                )
                ORDER BY f.scanOrder DESC
                LIMIT 1
                """.trimIndent(),
                null
            )

            if (cursor.moveToFirst()) {
                result = cursor.getString(0)
            }

            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return result

    }

    /**
     * ✅ NUEVO: Inserta una carpeta en la BD
     */
    fun insertFolder(parent: String?, path: String, name: String, scanOrder: Int) {
        try {
            val db = writableDatabase
            db.execSQL(
                """
                INSERT OR REPLACE INTO folders(parent, path, name, scanOrder)
                VALUES(?, ?, ?, ?)
                """.trimIndent(),
                arrayOf(parent ?: "", path, name, scanOrder)
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * ✅ NUEVO: Inserta una canción en la BD
     */
    fun insertSong(folderPath: String, fileName: String, title: String, uri: String) {
        try {
            val db = writableDatabase
            db.execSQL(
                """
                INSERT INTO songs(folderPath, fileName, title, track, duration, uri)
                VALUES(?, ?, ?, ?, ?, ?)
                """.trimIndent(),
                arrayOf(folderPath, fileName, title, 0, 0, uri)
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * ✅ NUEVO: Limpia la BD
     */
    fun clearDatabase() {
        try {
            val db = writableDatabase
            db.execSQL("DELETE FROM songs")
            db.execSQL("DELETE FROM folders")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

}