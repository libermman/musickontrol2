package com.dnc1981.musickontrol.manager

import android.content.Context
import androidx.media3.exoplayer.ExoPlayer
import android.util.Log

object ExoPlayerManager {
    private const val TAG = "ExoPlayerManager"
    private var exoPlayer: ExoPlayer? = null

    fun getInstance(context: Context): ExoPlayer {
        if (exoPlayer == null) {
            Log.d(TAG, "🎵 Creando nueva instancia de ExoPlayer (SINGLETON)")
            exoPlayer = ExoPlayer.Builder(context).build()
        }
        return exoPlayer!!
    }

    fun release() {
        Log.d(TAG, "❌ Liberando ExoPlayer")
        exoPlayer?.release()
        exoPlayer = null
    }

    fun isInitialized(): Boolean = exoPlayer != null
}