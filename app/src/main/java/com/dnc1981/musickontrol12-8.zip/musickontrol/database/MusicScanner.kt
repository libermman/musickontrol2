package com.dnc1981.musickontrol.database

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import com.dnc1981.musickontrol.debug.DebugLogOverlay

class MusicScanner(

    private val context: Context,

    private val database: MusicDatabaseHelper

) {

    private var scanOrder = 0

    fun scan(root: DocumentFile) {

        Thread {

            scanOrder = 0

            val db = database.writableDatabase

            db.beginTransaction()

            try {

                // ✅ COMENTADO: Descomenta para ver logs de escaneo
                // DebugLogOverlay.addLog("MusicScanner", "🔍 ========== INICIANDO ESCANEO ==========")
                // DebugLogOverlay.addLog("MusicScanner", "📁 Raíz: ${root.uri}")

                db.execSQL("DELETE FROM songs")
                db.execSQL("DELETE FROM folders")

                // DebugLogOverlay.addLog("MusicScanner", "🧹 BD limpiada")

                scanFolder(root)

                // DebugLogOverlay.addLog("MusicScanner", "✅ Escaneo completado. Total carpetas: $scanOrder")

                db.setTransactionSuccessful()

            } catch (e: Exception) {

                // DebugLogOverlay.addLog("MusicScanner", "❌ ERROR EN ESCANEO: ${e.message}", isError = true)
                e.printStackTrace()

            } finally {

                db.endTransaction()
                db.close()

                // DebugLogOverlay.addLog("MusicScanner", "✅ Transacción finalizada y BD cerrada")

            }

        }.start()

    }

    private fun scanFolder(
        folder: DocumentFile
    ): Boolean {

        if (!folder.isDirectory) {
            // DebugLogOverlay.addLog("MusicScanner", "⚠️  No es directorio: ${folder.name}")
            return false
        }

        var containsMusic = false

        try {

            val files = folder.listFiles().sortedBy {
                it.name?.lowercase() ?: ""
            }

            // DebugLogOverlay.addLog("MusicScanner", "📂 Escaneando: ${folder.name} (${files.size} elementos)")

            files.forEach { file ->

                if (file.isDirectory) {

                    if (scanFolder(file)) {
                        containsMusic = true
                    }

                } else {

                    if (isAudio(file.name)) {

                        containsMusic = true
                        saveSong(folder, file)

                    }

                }

            }

        } catch (e: Exception) {

            // DebugLogOverlay.addLog("MusicScanner", "❌ Error en carpeta ${folder.name}: ${e.message}", isError = true)
            e.printStackTrace()

        }

        if (containsMusic) {
            saveFolder(folder)
        }

        return containsMusic

    }

    private fun saveFolder(
        folder: DocumentFile
    ) {

        scanOrder++

        try {

            val db = database.writableDatabase

            db.execSQL(

                """
                INSERT OR REPLACE INTO folders(
                    parent,
                    path,
                    name,
                    scanOrder
                )
                VALUES(?,?,?,?)
                """.trimIndent(),

                arrayOf(

                    folder.parentFile?.uri?.toString() ?: "",

                    folder.uri.toString(),

                    folder.name ?: "",

                    scanOrder

                )

            )

            // DebugLogOverlay.addLog("MusicScanner", "📁 Guardada: ${folder.name} (#$scanOrder)")

        } catch (e: Exception) {

            // DebugLogOverlay.addLog("MusicScanner", "❌ Error guardando carpeta: ${e.message}", isError = true)
            e.printStackTrace()

        }

    }

    private fun saveSong(

        folder: DocumentFile,

        file: DocumentFile

    ) {

        try {

            val db = database.writableDatabase

            db.execSQL(

                """
                INSERT INTO songs(
                    folderPath,
                    fileName,
                    title,
                    track,
                    duration,
                    uri
                )
                VALUES(?,?,?,?,?,?)
                """.trimIndent(),

                arrayOf(

                    folder.uri.toString(),

                    file.name ?: "",

                    file.name
                        ?.substringBeforeLast(".")
                        ?: "",

                    extractTrack(file.name),

                    0,

                    file.uri.toString()

                )

            )

            // DebugLogOverlay.addLog("MusicScanner", "🎵 ${file.name}")

        } catch (e: Exception) {

            // DebugLogOverlay.addLog("MusicScanner", "❌ Error canción: ${e.message}", isError = true)
            e.printStackTrace()

        }

    }

    private fun extractTrack(
        name: String?
    ): Int {

        if (name == null)
            return 0

        val number = name.takeWhile {
            it.isDigit()
        }

        return number.toIntOrNull() ?: 0

    }

    private fun isAudio(
        name: String?
    ): Boolean {

        if (name == null)
            return false

        val n = name.lowercase()

        return n.endsWith(".mp3") ||
                n.endsWith(".flac") ||
                n.endsWith(".wav") ||
                n.endsWith(".aac") ||
                n.endsWith(".ogg") ||
                n.endsWith(".m4a") ||
                n.endsWith(".opus")

    }

}